using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;

public class clic : MonoBehaviour

{
    public scoreManager scoreManager;
    public float scoreAdd = 1;


    // Start is called before the first frame update

    private void OnMouseDown()
    {
        scoreManager.score = scoreManager.score + scoreAdd;
        
    }
}
